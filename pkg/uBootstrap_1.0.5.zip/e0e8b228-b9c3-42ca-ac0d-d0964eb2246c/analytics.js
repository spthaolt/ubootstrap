window._gaq = [['_setAccount', 'XX-XXXXXXXX-X'], ['_trackPageview'], ['_trackPageLoadTime']];
Modernizr.load({
    load: ('https:' == location.protocol ? '//ssl' : '//www') + '.google-analytics.com/ga.js'
});
