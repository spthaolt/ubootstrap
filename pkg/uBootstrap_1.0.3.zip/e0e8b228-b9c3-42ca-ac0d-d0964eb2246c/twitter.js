Modernizr.load([{
    load: '//widgets.twimg.com/j/2/widget.js',
    complete: function () {
        new TWTR.Widget({
            id: 'twtr-widget', version: 2, type: 'profile', rpp: 3, interval: 30000, width: 'auto', height: 250,
            theme: {
                shell: { background: '#f5f5f5', color: '#404040' },
                tweets: { background: '#f5f5f5', color: '#404040', links: '#cb1ec5' }
            },
            features: { scrollbar: false, loop: false, live: false, behavior: 'all' }
        }).render().setUser($('#twtr-widget').attr('data-user')).start();
    }
}]);
