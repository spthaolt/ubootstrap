﻿/* Open link in a new window using jQuery  */
$(document).ready(function () {
    $('a[rel="external"]').click(function () {
        window.open($(this).attr('href'));
        return false;
    });
});

/* Enabling twipsy */
$(function () {
    $("div.media-grid div a").twipsy({
        live: true
    });
});

